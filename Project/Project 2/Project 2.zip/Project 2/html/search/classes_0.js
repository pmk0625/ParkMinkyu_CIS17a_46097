var searchData=
[
  ['guesses',['guesses',['../structguesses.html',1,'']]]
];
