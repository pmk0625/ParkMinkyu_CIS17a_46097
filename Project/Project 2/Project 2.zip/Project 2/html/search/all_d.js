var searchData=
[
  ['yellow',['YELLOW',['../main_8cpp.html#aedd64c3f92da850b93776c65fd1cced3ae735a848bf82163a19236ead1c3ef2d2',1,'main.cpp']]]
];
