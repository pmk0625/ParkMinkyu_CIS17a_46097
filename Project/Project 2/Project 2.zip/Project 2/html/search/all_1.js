var searchData=
[
  ['blue',['BLUE',['../main_8cpp.html#aedd64c3f92da850b93776c65fd1cced3a35d6719cb4d7577c031b3d79057a1b79',1,'main.cpp']]]
];
