var searchData=
[
  ['green',['GREEN',['../main_8cpp.html#aedd64c3f92da850b93776c65fd1cced3aa60bd322f93178d68184e30e162571ca',1,'main.cpp']]]
];
