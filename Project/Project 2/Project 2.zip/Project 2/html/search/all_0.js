var searchData=
[
  ['answer',['answer',['../main_8cpp.html#aad514542ef691c394466ac3b534db098',1,'main.cpp']]]
];
