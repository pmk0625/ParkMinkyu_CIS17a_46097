var searchData=
[
  ['purple',['PURPLE',['../main_8cpp.html#aedd64c3f92da850b93776c65fd1cced3a2772ad7cd64f03c2aed60f91c69fa69d',1,'main.cpp']]]
];
