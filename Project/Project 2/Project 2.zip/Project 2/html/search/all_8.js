var searchData=
[
  ['orange',['ORANGE',['../main_8cpp.html#aedd64c3f92da850b93776c65fd1cced3ace9ee4c1a6b777940c7f3a766a9a88d4',1,'main.cpp']]]
];
